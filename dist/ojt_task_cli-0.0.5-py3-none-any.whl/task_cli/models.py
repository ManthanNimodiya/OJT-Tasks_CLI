import datetime
from dataclasses import dataclass, asdict
from typing import Optional, Dict, Any

@dataclass
class Task:
    """
    Represents a single task in the system.
    """
    id: int
    title: str
    status: str = "pending"
    priority: str = "Medium"
    project: Optional[str] = None
    recurrence: Optional[str] = None
    created_at: str = "" 
    completed_at: Optional[str] = None
    due_date: Optional[str] = None
    relist_count: int = 0

    def __post_init__(self) -> None:
        """Sets the creation timestamp if not provided."""
        if not self.created_at:
            self.created_at = datetime.datetime.now().isoformat()

    def to_dict(self) -> Dict[str, Any]:
        """Converts the task to a dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Task':
        """
        Creates a Task instance from a dictionary.
        Filters out unknown fields for backward compatibility.
        """
        # Filter data to only include fields that are in the dataclass
        # This ensures backward compatibility if the saved JSON has extra fields (like relist_count)
        valid_fields = {f for f in cls.__annotations__}
        filtered_data = {k: v for k, v in data.items() if k in valid_fields}
        return cls(**filtered_data)
